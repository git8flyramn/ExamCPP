#include "stdio.h"
#include "stdlib.h"
#include "time.h"
#include "iostream"
int main()
{
	srand((unsigned) time(NULL));
	int com1,com2;
	int W1 = 0, W2 = 0;
	int count = 0;
	int r1 = 0, r2 = 0;
	
	
	do
	{
		r1 = rand() % 2 + 0;
		r2 = rand() % 2 + 0;
		//0;gu 1;pa 2:choki
		com1 = r1;
		com2 = r2;
		 if(com1 == 0)
		{
			if (com1 == com2)
			{
				std::cout << "��������" << "\n";
				count += 1;

			}
			else if (com2 == 2)
			{
				std::cout << "com1�̏���" << "\n";
				W1 += 1;
				count += 1;

			}
			else if (com2 == 1)
			{
				std::cout << "com2�̏���" << "\n";
				W2 += 1;
				count += 1;

			}

		}
		 if (com1 == 1)
		 {
			 if (com1 == com2)
			 {
				 std::cout << "��������" << "\n";
				 count += 1;
			 }
			 else if (com2 == 0)
			 {
				 std::cout << "com1�̏���" << "\n";
				 W1 += 1;
				 count += 1;

			 }
			 else if (com2 == 2)
			 {
				 std::cout << "com2�̏���" << "\n";
				 W2 += 1;
				 count += 1;

			 }
		 }
		 if(com1 == 2)
		{
			if (com1 == com2)
			{
				std::cout << "��������" << "\n";
				count += 1;
			}
			else if (com2 == 1)
			{
				std::cout << "com1�̏���" << "\n";
				W1 += 1;
			    count += 1;
				
			}
			else if (com2 == 0)
			{
				std::cout << "com1�̏���" << "\n";
				W1 += 1;
				count += 1;
			}
		}
	} while (count < 3);
	if (W1 > W2)
	{
		std::cout << "com1�̏���" << "\n";
	}
	else if(W1 < W2) 
	{
		std::cout << "com2�̏���" << "\n";
	}
	else
	{
		std::cout << "���҈�������\n";
	}
}